
# Lethal ZGAF   
A Lethal Company mod pack for ZeroGravityAntFarm. This pack is a good balance of new content, stability, and QOL fixes. 

https://github.com/Sphyrna-029/Lethal-ZGAF

